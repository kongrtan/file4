using System;

namespace RvSampleNet10
{
    public class ConsoleLogger : ILogger
    {
        public void Info(string format, params object[] args) => Write("INFO", format, args);
        public void Warn(string format, params object[] args) => Write("WARN", format, args);
        public void Error(string format, params object[] args) => Write("ERROR", format, args);

        private void Write(string level, string format, params object[] args)
        {
            string msg = string.Format(format, args);
            Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] [{level}] {msg}");
        }
    }
}