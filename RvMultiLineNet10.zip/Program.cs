using System;

namespace RvSampleNet10
{
    class Program
    {
        static void Main()
        {
            ILogger logger = new ConsoleLogger();
            var manager = new RvManager(logger);

            for (int i = 1; i <= 10; i++)
                manager.AddLine(i, $"tcp:10.0.0.{i}:7500");

            manager.StartAll();

            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();

            manager.StopAll();
        }
    }
}