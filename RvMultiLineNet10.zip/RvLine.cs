using System;
using System.Threading;

namespace RvSampleNet10
{
    public class RvLine
    {
        public int LineId { get; init; }
        public string Daemon { get; init; }
        private readonly ILogger _logger;
        private bool _connected = false;
        private Timer? _heartbeatTimer;

        public RvLine(int lineId, string daemon, ILogger logger)
        {
            LineId = lineId;
            Daemon = daemon;
            _logger = logger;
        }

        public void Start()
        {
            _logger.Info($"[Line:{LineId}] [{Daemon}] START");

            ConnectTransport();

            // Heartbeat Timer 1초 간격
            _heartbeatTimer = new Timer(Heartbeat, null, 1000, 1000);
        }

        private void Heartbeat(object? state)
        {
            try
            {
                if (!_connected)
                {
                    _logger.Warn($"[Line:{LineId}] [{Daemon}] Transport disconnected, reconnecting...");
                    Reconnect();
                }
            }
            catch (Exception ex)
            {
                _logger.Error($"[Line:{LineId}] Heartbeat error: {ex.Message}");
            }
        }

        private void ConnectTransport()
        {
            // 실제 RvTransport 연결 코드 자리
            _connected = true;
            _logger.Info($"[Line:{LineId}] Transport connected to {Daemon}");
        }

        private void Reconnect()
        {
            try
            {
                _connected = false;
                ConnectTransport();
                _logger.Info($"[Line:{LineId}] Reconnected successfully");
            }
            catch (Exception ex)
            {
                _logger.Error($"[Line:{LineId}] Reconnect failed: {ex.Message}");
            }
        }

        public void Stop()
        {
            _heartbeatTimer?.Dispose();
            _connected = false;
            _logger.Info($"[Line:{LineId}] STOP");
        }
    }
}