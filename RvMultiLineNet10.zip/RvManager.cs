using System.Collections.Generic;

namespace RvSampleNet10
{
    public class RvManager
    {
        private readonly List<RvLine> _lines = new();
        private readonly ILogger _logger;

        public RvManager(ILogger logger) => _logger = logger;

        public void AddLine(int id, string daemon) =>
            _lines.Add(new RvLine(id, daemon, _logger));

        public void StartAll()
        {
            foreach (var line in _lines) line.Start();
            _logger.Info("All lines started");
        }

        public void StopAll()
        {
            foreach (var line in _lines) line.Stop();
            _logger.Info("All lines stopped");
        }
    }
}