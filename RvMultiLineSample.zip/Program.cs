using System;

namespace RvSample
{
    class Program
    {
        static void Main(string[] args)
        {
            var manager = new RvManager();

            for (int i = 1; i <= 10; i++)
            {
                manager.AddLine(i, string.Format("tcp:10.0.0.{0}:7500", i));
            }

            manager.StartAll();

            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();

            manager.StopAll();
        }
    }
}