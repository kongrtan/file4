# RV Multi Line Sample

- rvd 10대
- Queue / Transport / Listener 1:1:1 구조
- RvLine 객체 단위 관리
- RvManager로 전체 제어

TIBCO RV API 연동 코드는 Start() 내부에 추가하세요.