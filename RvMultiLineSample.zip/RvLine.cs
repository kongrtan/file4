using System;

namespace RvSample
{
    public class RvLine
    {
        public int LineId { get; private set; }
        public string Daemon { get; private set; }

        public RvLine(int lineId, string daemon)
        {
            LineId = lineId;
            Daemon = daemon;
        }

        public void Start()
        {
            Console.WriteLine(string.Format("RvLine {0} START ({1})", LineId, Daemon));
            // Queue / Transport / Listener / Dispatcher 생성 위치
        }

        public void Stop()
        {
            Console.WriteLine(string.Format("RvLine {0} STOP", LineId));
        }
    }
}