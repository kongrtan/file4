using System.Collections.Generic;

namespace RvSample
{
    public class RvManager
    {
        private List<RvLine> lines = new List<RvLine>();

        public void AddLine(int id, string daemon)
        {
            lines.Add(new RvLine(id, daemon));
        }

        public void StartAll()
        {
            foreach (var line in lines)
                line.Start();
        }

        public void StopAll()
        {
            foreach (var line in lines)
                line.Stop();
        }
    }
}